# Wireless Outdoor Color Chaning LED Floating Duck Speaker
By Power Beauty Industrial Ltd.

---

Sold at Sams club a while back but seems to be functionaly identical to the ones sold today on the major sites.

Remote says `SPEAKERLIGHTING` on it and has 22 buttons.

* This is the exact one: https://www.samsclub.com/p/wireless-outdoor-color-chaning-led-floating-duck-with-speaker/prod22630627
* FCC manual Members Mark Branded: https://fccid.io/2AC37PBB-2835S/User-Manual/User-Manual-3961075



> **Copied from Sams club for archival use:**
> 
> This ball-shaped wireless Bluetooth speaker can float in the pool and all kinds of water or accompany kids in the bathtub!
> It's very safe for the human body. The LED floating Bluetooth speaker controls the change of light and music size through a wireless infrared remote control.
> Four modes include flash, monochrome, smooth, timing. Lighting in FLASH mode changes with the rhythm of the music.
> Waterproof to the highest level, it can be used indoors and outdoors.
> 
> ## Safe and Waterproof
> There is a rotating speaker on the back of the duck sound (not suitable for all immersed in water).
> Our products are made of imported environmentally-friendly PE plastic, anti-ultraviolet, nontoxic, safe, anti-drop and wear-resistant, super durable and can last up to 2 years.
> All of our products are safety certified. Use this KTV, bars, cafes, discos, clubs, parks, gardens, swimming pools and other leisure and entertainment venues and families, villas, residential areas.
> Safe and environmentally friendly.
>
>    Material: PE plastic housing
>    Speaker: 1x 5W Bluetooth speaker
>    Battery: 1x 3.7V,2200MAH Li-ion battery
>    LED: 12 pieces RGB LEDs + 6 pieces white LEDs
>    Charge: Adapter 7.5V 0.6A with charging base
>    Control: 22 key remote control
>    Product Size: 11.8"x 10.6" x 11.8"
>    Packaging: 1 piece each color box
>    Net Weight: 2.62 lbs.
>
> * **Material**: PE plastic housing
> * **Speaker**: 1x 5W Bluetooth speaker
> * **Battery**: 1x 3.7V,2200MAH Li-ion battery
> * **LED**: 12 pieces RGB LEDs + 6 pieces white LEDs
> * **Charge**: Adapter 7.5V 0.6A with charging base
> * **Control**: 22 key remote control
> * **Product Size**: 11.8"x 10.6" x 11.8"
> * **Packaging**: 1 piece each color box
> * **Net Weight**: 2.62 lbs.
>
> |                       |                                                                          |
> | --------------------- | ------------------------------------------------------------------------ |
> | **Assembled Size**    | 11.8"Lx11.8"Wx10.6"H                                                     |
> | **Warranty**          | This product is covered by the Sam's Club Member Satisfaction Guarantee. |
> | **Component country** | Imported                                                                 |
> | **Assembled country** | China                                                                    |
