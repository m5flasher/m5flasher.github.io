# BoomTone DJ-LEDPAR 7x10W 5-in-1
Thanks Foul for the files!

REMOTE<br>
![remote](https://github.com/UberGuidoZ/Flipper-IRDB/assets/57457139/10b8d8e0-164d-4ec2-bbbc-2a6afc082318)

FRONT<br>
![Front](https://github.com/UberGuidoZ/Flipper-IRDB/assets/57457139/d855aac8-9052-42b0-8b12-b19c15908306)

BACK<br>
![Back](https://github.com/UberGuidoZ/Flipper-IRDB/assets/57457139/07eec84b-0283-4daa-b672-7b83caafa4d1)
